from django.contrib import admin
from .models import SavedSearches
# Register your models here.
admin.site.register(SavedSearches)